# SoftSync INC

---

## A Software Development, Web Development & Digital Marketing providing organization.


After download:
1. yarn install
2. development mood a run korte: yarn run dev
3. build korte: yarn run build

