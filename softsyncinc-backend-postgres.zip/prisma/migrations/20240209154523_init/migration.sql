-- AlterTable
ALTER TABLE "blogs" ALTER COLUMN "blogStatus" DROP NOT NULL;
