-- DropIndex
DROP INDEX "blogs_authorId_key";
