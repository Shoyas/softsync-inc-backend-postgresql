-- AlterTable
ALTER TABLE "founders" ADD COLUMN     "founderPersonImg" TEXT;

-- AlterTable
ALTER TABLE "team-members" ADD COLUMN     "teamPersonImg" TEXT;
