-- AlterTable
ALTER TABLE "services" ADD COLUMN     "serviceImg" TEXT;
