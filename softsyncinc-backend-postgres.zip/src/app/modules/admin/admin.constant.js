"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.adminFilterableFields = exports.adminSearchableFields = exports.adminRoleEnum = void 0;
exports.adminRoleEnum = ['admin', 'super_admin'];
exports.adminSearchableFields = ['userName', 'role', 'id'];
exports.adminFilterableFields = ['searchTerm', 'role'];
