export type IAdminRoleEnum = 'super_admin' | 'admin';

export type IAdminFilters = {
  searchTerm?: string;
  role?: string;
};
