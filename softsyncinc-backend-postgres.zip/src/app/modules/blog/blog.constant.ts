export const blogSearchableFields = ['blogTitle', 'blogContent', 'authorId'];

export const blogFilterableFields: string[] = ['searchTerm'];
