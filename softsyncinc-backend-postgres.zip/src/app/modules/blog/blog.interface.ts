export type IBlogFilters = {
  searchTerm?: string;
};
  