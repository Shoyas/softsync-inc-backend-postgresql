"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.categoryFilterableFields = exports.categorySearchableFields = void 0;
exports.categorySearchableFields = ['categoryTitle'];
exports.categoryFilterableFields = ['searchTerm'];
