export const categorySearchableFields = ['categoryTitle'];

export const categoryFilterableFields: string[] = ['searchTerm'];
