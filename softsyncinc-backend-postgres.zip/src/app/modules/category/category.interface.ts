export type ICategoryFilters = {
  searchTerm?: string;
};
