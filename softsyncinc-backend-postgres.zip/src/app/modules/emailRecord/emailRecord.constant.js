"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.emailRecordFilterableFields = exports.emailRecordSearchableFields = void 0;
exports.emailRecordSearchableFields = ['email', 'name'];
exports.emailRecordFilterableFields = ['searchTerm'];
