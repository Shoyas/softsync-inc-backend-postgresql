export const emailRecordSearchableFields = ['email', 'name'];

export const emailRecordFilterableFields: string[] = ['searchTerm'];
