export type IEmailRecordFilters = {
  searchTerm?: string;
};
