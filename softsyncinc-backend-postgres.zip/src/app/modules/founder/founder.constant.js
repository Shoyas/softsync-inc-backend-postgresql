"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.founderFilterableFields = exports.founderSearchableFields = void 0;
exports.founderSearchableFields = ['name', 'designation'];
exports.founderFilterableFields = ['searchTerm'];
