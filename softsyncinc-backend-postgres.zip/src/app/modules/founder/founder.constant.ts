export const founderSearchableFields = ['name', 'designation'];

export const founderFilterableFields: string[] = ['searchTerm'];
