export type IFounderFilters = {
  searchTerm?: string;
};
