"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.serviceFilterableFields = exports.serviceSearchableFields = void 0;
exports.serviceSearchableFields = ['serviceTitle', 'categoryTitle'];
exports.serviceFilterableFields = ['searchTerm'];
