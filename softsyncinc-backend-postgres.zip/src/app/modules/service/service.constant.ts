export const serviceSearchableFields = ['serviceTitle', 'categoryTitle'];

export const serviceFilterableFields: string[] = ['searchTerm'];
