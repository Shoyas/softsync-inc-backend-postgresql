export type IServiceFilters = {
  searchTerm?: string;
};
