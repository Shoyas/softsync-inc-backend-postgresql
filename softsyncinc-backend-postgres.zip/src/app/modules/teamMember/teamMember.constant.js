"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.teamMemberFilterableFields = exports.teamMemberSearchableFields = void 0;
exports.teamMemberSearchableFields = ['name', 'designation'];
exports.teamMemberFilterableFields = ['searchTerm'];
