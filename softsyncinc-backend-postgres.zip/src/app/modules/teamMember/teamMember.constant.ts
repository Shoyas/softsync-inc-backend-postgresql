export const teamMemberSearchableFields = ['name', 'designation'];

export const teamMemberFilterableFields: string[] = ['searchTerm'];
