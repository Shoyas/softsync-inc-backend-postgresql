export type ITeamMemberFilters = {
  searchTerm?: string;
};
 