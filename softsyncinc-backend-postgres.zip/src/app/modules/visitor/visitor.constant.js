"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.visitorFilterableFields = exports.visitorSearchableFields = void 0;
exports.visitorSearchableFields = ['browser_name'];
exports.visitorFilterableFields = ['searchTerm'];
