export const visitorSearchableFields = ['browser_name'];

export const visitorFilterableFields: string[] = ['searchTerm'];
