export type IVisitorFilters = {
  searchTerm?: string;
};
