"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.workFilterableFields = exports.workSearchableFields = void 0;
exports.workSearchableFields = ['title', 'description', 'authorId'];
exports.workFilterableFields = ['searchTerm'];
