export const workSearchableFields = ['title', 'description', 'authorId'];

export const workFilterableFields: string[] = ['searchTerm'];
