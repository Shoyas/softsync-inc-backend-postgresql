export type IWorkFilters = {
  searchTerm?: string;
};
