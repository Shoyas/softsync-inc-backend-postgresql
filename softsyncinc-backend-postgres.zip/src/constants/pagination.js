"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.paginationFields = void 0;
exports.paginationFields = ['page', 'limit', 'sortBy', 'sortOrder'];
