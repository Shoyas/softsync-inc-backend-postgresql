"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ENUM_ADMIN_ROLE = void 0;
/* eslint-disable no-unused-vars */
var ENUM_ADMIN_ROLE;
(function (ENUM_ADMIN_ROLE) {
    ENUM_ADMIN_ROLE["SUPER_ADMIN"] = "super_admin";
    ENUM_ADMIN_ROLE["ADMIN"] = "admin";
})(ENUM_ADMIN_ROLE || (exports.ENUM_ADMIN_ROLE = ENUM_ADMIN_ROLE = {}));
