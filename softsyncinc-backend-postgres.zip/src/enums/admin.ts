/* eslint-disable no-unused-vars */
export enum ENUM_ADMIN_ROLE {
  SUPER_ADMIN = 'super_admin',
  ADMIN = 'admin',
}
